#ifndef GAME_H
#define GAME_H

#include "Deck.h"
#include "Hand.h"

namespace Poker {
    class Game {
    private:
        Deck deck;
        std::vector<Hand> hands;
        Hand communityCards;

    public:
        Game(int players);
        void ShowHands();
        void ShowHandsWithScore();
    };
}

#endif