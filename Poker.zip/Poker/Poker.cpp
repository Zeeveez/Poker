﻿// Poker.cpp : Defines the entry point for the application.
//

#include "Deck.h"
#include "Hand.h"
#include <iostream>


int main()
{
    std::cout << R"(################################################################################)" << "\n";
    std::cout << R"(#     /\                                                              _   _    #)" << "\n";
    std::cout << R"(#    <  >                        ___                                 / \_/ \   #)" << "\n";
    std::cout << R"(#  /\_||_/\                     / __\                               |       |  #)" << "\n";
    std::cout << R"(# <  _  _  >               _/\  \ \___                               \     /   #)" << "\n";
    std::cout << R"(#  \/ || \/               / _ \  \___ \                               \   /    #)" << "\n";
    std::cout << R"(#    /__\                |  \| \__ _/ /                                \_/     #)" << "\n";
    std::cout << R"(#        __            /\ \    __/ \_/                                         #)" << "\n";
    std::cout << R"(#     __/  \  ___  ___/ /_ \__/  __   __  _____  _    ____                     #)" << "\n";
    std::cout << R"(#  __/    _/ / _ \ \_   __|     |  |_|  ||  _  || |  |  _ \                    #)" << "\n";
    std::cout << R"(#  \      \ \ |/ |   / /        |   _   || |_| || |_ | |_| |                   #)" << "\n";
    std::cout << R"(#   \__/\  \ \  /_/\ \/         |__| |__||_____||___||____/                    #)" << "\n";
    std::cout << R"(#        \  \ \____/                   _   ______   __    __           __      #)" << "\n";
    std::cout << R"(#     /\  \_/                         | | |  ____| |  \  /  |         /  \     #)" << "\n";
    std::cout << R"(#    /  \                            /_/  | |__    |   \/   |        /    \    #)" << "\n";
    std::cout << R"(#   /    \                                |  __|   | |\  /| |       /      \   #)" << "\n";
    std::cout << R"(#   \    /                                | |____  | | \/ | |      |  _  _  |  #)" << "\n";
    std::cout << R"(#    \  /                                 |______| |_|    |_|      \_/ || \_/  #)" << "\n";
    std::cout << R"(#     \/                                                              /__\     #)" << "\n";
    std::cout << R"(################################################################################)" << "\n";
    Poker::Deck deck;
    int x = 0;
    int iter = 10000000000;
    std::map<std::string, int> counts = {
        { "Royal Flush", 0 },
        { "Straight Flush", 0 },
        { "Four of a Kind", 0 },
        { "Full House", 0 },
        { "Flush", 0 },
        { "Straight", 0 },
        { "Three of a Kind", 0 },
        { "Two Pair", 0 },
        { "Pair", 0 },
        { "High Card", 0 }
    };
    for (int i = 0; i < iter; i++) {
        Poker::Hand h;
        h.Draw(deck, 7);
        std::string rawScore = h.Score();
        std::string score = rawScore.substr(0, rawScore.find(" -"));
        if (counts.contains(score)) {
            counts[score]++;
        }
        else {
            counts["High Card"]++;
        }
        h.Discard(deck);
    }
    for (auto& kvp : counts) {
        std::cout << kvp.first << ": " << 100.0 * kvp.second / iter << "\n";
    }
}
