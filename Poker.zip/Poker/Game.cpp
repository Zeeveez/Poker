#include "Game.h"

#include <iostream>

namespace Poker {
    // ----------------------------   Public   ----------------------------
    Game::Game(int players) :deck(Deck()), hands({}), communityCards({}) {
        for (int i = 0; i < players; i++) {
            hands.push_back({});
            hands.back().Draw(deck, 2);
        }
        communityCards.Draw(deck,5);
    }

    void Game::ShowHands() {
        for (auto& hand : hands) {
            std::cout << hand << "\n";
        }
        std::cout << "Community " << communityCards << "\n";
    }

    void Game::ShowHandsWithScore() {
        for (auto& hand : hands) {
            std::cout << (hand + communityCards) << "\n";
            std::cout << (hand + communityCards).Score() << "\n";
        }
    }

    // ----------------------------  Private  ----------------------------
    // ---------------------------- Operators ----------------------------
}