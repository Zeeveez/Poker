#ifndef HAND_H
#define HAND_H

#include "Card.h"
#include "Deck.h"

#include <ostream>

namespace Poker {
    class Hand {
    private:
        std::vector<Card> cards;
        std::pair<bool, Card::Rank> StraightFlush(uint64_t hand);                                    // Rank of high card - A for royal flush
        std::pair<bool, std::pair<Card::Rank, Card::Rank>> FourOfAKind(uint64_t hand);               // Rank of four of a kind, plus rank of kicker
        std::pair<bool, std::pair<Card::Rank, Card::Rank>> FullHouse(uint64_t hand);                 // Rank of triple, plus rank of pair
        std::pair<bool, std::vector<Card::Rank>> Flush(uint64_t hand);                               // Ranks of cards
        std::pair<bool, Card::Rank> Straight(uint64_t hand);                                         // Rank of high card
        std::pair<bool, std::pair<Card::Rank, std::vector<Card::Rank>>> ThreeOfAKind(uint64_t hand); // Rank of triple, plus rank of kickers
        std::pair<bool, std::pair<std::vector<Card::Rank>, Card::Rank>> TwoPair(uint64_t hand);      // Ranks of pairs, plus rank of kicker
        std::pair<bool, std::pair<Card::Rank, std::vector<Card::Rank>>> Pair(uint64_t hand);         // Rank of pair, plus ranks of kickers
        std::vector<Card::Rank> HighCard();                                                          // Ranks of cards

    public:
        Hand();
        void Draw(Deck& deck);
        void Draw(Deck& deck, int n);
        void Discard(Deck& deck);
        std::string Score();
        Hand operator+(const Hand& other);
        friend std::ostream& operator<<(std::ostream& os, const Hand& hand);
    };
}

#endif